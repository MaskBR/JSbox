function getCover(inPut) {
  $http.get({
    url:'http://www.seedmm.work/'+inPut,
    header:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
    },
    handler:function(resp){
      var data=resp.data.match(/class="bigImage" href="(\S*?)"/)[1]
      $ui.push({
        views: [
          {
            type: "scroll",
            props: {
              zoomEnabled: true,
              maxZoomScale: 3, // Optional, default is 2,
              doubleTapToZoom: false // Optional, default is true
            },
            layout:function(make,view){
                              make.top.equalTo(view.super)
                              make.size.equalTo($size(375,200))
                            },
            views: [
              {
                type: "image",
                props: {
                  src:data
                },
            layout:$layout.fill
                }
            ]
          }
        ]
      });
    }
  });
  //($("spinner[0]").loading)=false
}

module.exports = {
  getCover: getCover
}
