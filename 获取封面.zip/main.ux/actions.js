const app = require("./scripts/getCover");

exports.tapped = sender => {
  $device.taptic(1),
  ($("spinner[0]").loading)=true,
  app.getCover($("input[0]").text);
}

exports.changed = (sender) => {
  $device.taptic(0),
  $input.text({
    type:$kbType.number,
    placeholder:"input",
    handler:function(text){
        $("input[0]").text=sender.items[sender.index]+"-"+text
    }
  })
}
