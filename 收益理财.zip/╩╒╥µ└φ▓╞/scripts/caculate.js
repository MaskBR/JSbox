function finanialIncome(rate,principal,date) {
  income=principal*rate/365*date
  return income
}

module.exports = {
  finanialIncome: finanialIncome
}