const app = require("./scripts/caculate");

exports.tapped = sender => {
  app.caculate($("rate").text,$("principal").text,$("date").text)
}