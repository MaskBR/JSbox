function caculate(rate,principal,date) {
  var income=principal*rate/365*date
  $ui.alert("年化收益为:"+income.toFixed(3))
}

module.exports = {
  caculate: caculate
}

