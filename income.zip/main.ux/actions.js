const app = require("./scripts/caculate");

exports.tapped = sender => {
   app.caculate($("rate").text,$("principal").text,$("date").text)
}


exports.didBeginEditing = (sender) => {
  $device.taptic(0)
  sender.focus()
}
